Migration README

Purpose
- Add six subject columns to `student_info` and optionally migrate existing marks.

Important: BACKUP your database before running any statements.

Backup example (run in PowerShell):

```powershell
mysqldump -u root -p -h 127.0.0.1 -P 3306 giet_exam > backup_giet_exam_20251127.sql
```

Apply migration (example):

```powershell
mysql -u root -p -h 127.0.0.1 -P 3306 giet_exam < migrations/20251127_add_subjects_and_migrate.sql
```

Notes & required confirmations
- Confirm which database to modify: `giet_exam` (used by `php/student-result-form.php`) or another DB (some files referenced a different DB name/port).
- Confirm column mapping for migrating old marks. The migration script includes an example mapping (commented).
- If you prefer to handle mapping manually, edit the `UPDATE student_info SET ...` section accordingly or leave migrated columns as 0 and enter values via admin UI.

After migration
- Verify a few rows with:

```sql
SELECT name, regno, mathematics, ddco, os, dsa, oops, dvpy, total, status FROM student_info LIMIT 10;
```

- If you want, I can run the SQL locally (requires DB credentials) or update the admin upload script to save marks into the new columns.
