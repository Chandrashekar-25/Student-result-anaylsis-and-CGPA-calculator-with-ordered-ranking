-- Migration: add new subject columns and (optional) migrate from existing columns
-- PLEASE BACKUP your database first (see README for commands)

-- 1) Add new subject columns (run only if they do not already exist)
ALTER TABLE `student_info`
  ADD COLUMN `mathematics` INT DEFAULT 0,
  ADD COLUMN `ddco` INT DEFAULT 0,
  ADD COLUMN `os` INT DEFAULT 0,
  ADD COLUMN `dsa` INT DEFAULT 0,
  ADD COLUMN `oops` INT DEFAULT 0,
  ADD COLUMN `dvpy` INT DEFAULT 0;

-- 2) Optional: migrate existing marks into the new columns
-- NOTE: Review and confirm the mapping below before running.
-- Current table appears to have columns: `math-2`, `dsa`, `be`, `chemistry`, `cetc` (and maybe others).
-- Suggested mapping (example):
--   `math-2`   -> `mathematics`
--   `dsa`      -> `dsa` (same)
--   `be`       -> `ddco` (if you want to keep BE data under DDCO)
--   `chemistry`-> `os` (example mapping)
--   `cetc`     -> `oops` (example mapping)
--   `dvpy`     -> left as 0 (no previous column)

-- Run the UPDATE below only after you confirm the mapping is acceptable.
UPDATE `student_info` SET
  `mathematics` = COALESCE(`math-2`, 0),
  `dsa` = COALESCE(`dsa`, 0),
  `ddco` = COALESCE(`be`, 0),
  `os` = COALESCE(`chemistry`, 0),
  `oops` = COALESCE(`cetc`, 0),
  `dvpy` = COALESCE(`dvpy`, 0);

-- 3) Recompute subtotal/total column (if you want to store it)
-- Add `total` column if missing
ALTER TABLE `student_info` ADD COLUMN IF NOT EXISTS `total` INT DEFAULT 0;

UPDATE `student_info` SET
  `total` = COALESCE(`mathematics`,0) + COALESCE(`ddco`,0) + COALESCE(`os`,0) + COALESCE(`dsa`,0) + COALESCE(`oops`,0) + COALESCE(`dvpy`,0);

-- 4) Update `status` based on per-subject pass (pass >= 40) and percent >=40
-- Create/ensure `status` column exists
ALTER TABLE `student_info` ADD COLUMN IF NOT EXISTS `status` VARCHAR(10) DEFAULT 'Fail';

UPDATE `student_info` SET `status` =
  CASE WHEN (
    (COALESCE(`mathematics`,0) >= 40) AND
    (COALESCE(`ddco`,0) >= 40) AND
    (COALESCE(`os`,0) >= 40) AND
    (COALESCE(`dsa`,0) >= 40) AND
    (COALESCE(`oops`,0) >= 40) AND
    (COALESCE(`dvpy`,0) >= 40) AND
    ((COALESCE(`mathematics`,0)+COALESCE(`ddco`,0)+COALESCE(`os`,0)+COALESCE(`dsa`,0)+COALESCE(`oops`,0)+COALESCE(`dvpy`,0))/600.0*100 >= 40)
  ) THEN 'Pass' ELSE 'Fail' END;

-- End of migration script
