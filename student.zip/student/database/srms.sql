
CREATE DATABASE IF NOT EXISTS srms;
USE srms;

CREATE TABLE admin(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(255)
);

INSERT INTO admin(username,password) VALUES('admin','admin123');

CREATE TABLE students(
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100),
 usn VARCHAR(20),
 dept VARCHAR(50),
 password VARCHAR(255)
);

CREATE TABLE results(
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT,
 mathematics INT,
 ddco INT,
 os INT,
 dsa INT,
 java INT,
 dvp INT,
 total INT,
 cgpa FLOAT,
 FOREIGN KEY(student_id) REFERENCES students(id)
);
