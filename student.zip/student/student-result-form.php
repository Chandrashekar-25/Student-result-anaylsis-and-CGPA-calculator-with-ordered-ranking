<?php
include 'config.php';
$student=null;$message="";
function vtu_grade_point($m){ if($m>=90)return 10; if($m>=80)return 9; if($m>=70)return 8; if($m>=60)return 7; if($m>=55)return 6; if($m>=50)return 5; if($m>=45)return 4; return 0;}
if(isset($_POST['submit'])){
    $regno=$_POST['regno'];
    $res=mysqli_query($conn,"SELECT * FROM vtu_results WHERE regno='$regno'");
    if(mysqli_num_rows($res)>0){
        $student=mysqli_fetch_assoc($res);
        $marks=['math'=>$student['math'],'ddco'=>$student['ddco'],'os'=>$student['os'],'dsa'=>$student['dsa'],'java'=>$student['java'],'dvp'=>$student['dvp']];
        $total=array_sum($marks);$percentage=round($total/600*100,2);
        $gp=array_map('vtu_grade_point',$marks);$cgpa=round(array_sum($gp)/6,2);
        $fail=false;foreach($marks as $m){if($m<45)$fail=true;}
        $result_status=$fail?'FAIL':'PASS';
    } else $message="No record found";
}
?>
<!DOCTYPE html><html><head><title>Student Result</title></head><body>
<h2>Student Result Portal</h2>
<form method="POST"><label>Register Number:</label>
<input type="text" name="regno" required><button name="submit">View Result</button></form>
<?php if($message) echo "<script>alert('$message');</script>"; ?>
<?php if($student): ?>
<h3>Total: <?php echo $total;?> | Percentage: <?php echo $percentage;?>% | CGPA: <?php echo $cgpa;?></h3>
<h3>Status: <?php echo $result_status;?></h3>
<a href="ranking_total.php">Ranking Total</a><br><a href="ranking_cgpa.php">Ranking CGPA</a>
<?php endif; ?>
</body></html>
