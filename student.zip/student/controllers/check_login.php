<?php
session_start();
// IMPORTANT: Ensure you have a working config.php defining $conn
// If config.php is missing, replace the line below with your direct connection string:
// $conn = mysqli_connect("localhost", "root", "", "srms");
include '../config.php'; 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../auth/login.php');
    exit;
}

$role = $_POST['role'];
$u = $_POST['username'];
$p = $_POST['password'];

if ($role === 'admin') {
    // 🔒 FIX: Use Prepared Statement to fetch the hashed password
    $stmt = $conn->prepare("SELECT password FROM admin WHERE username=?");
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // 🔒 FIX: Use password_verify() to securely check the hash
        if (password_verify($p, $row['password'])) {
            $_SESSION['admin'] = $u; // ✅ SETS THE CORRECT 'admin' KEY
            header('Location: ../admin/dashboard.php');
            exit;
        }
    }
} elseif ($role === 'student') {
    // 🔒 FIX: Use Prepared Statement for Student Login
    $stmt = $conn->prepare("SELECT usn FROM students WHERE usn=? AND password=?");
    $stmt->bind_param("ss", $u, $p);
    $stmt->execute();
    $result = $stmt->get_result();

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['student'] = $u;
        header('Location: ../student/home.php');
        exit;
    }
}

// If no successful login (for admin or student)
echo "<script>alert('Invalid Login'); window.location='../auth/login.php';</script>";
exit;
?>