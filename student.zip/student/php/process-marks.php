<?php
// Database connection
$con = mysqli_connect("localhost", "root", "", "vtu_result", "3306");

if(!$con){
    die("Database connection failed!");
}

// Collect data
$regno = $_POST['regno'];
$m0 = $_POST['m0'];
$m1 = $_POST['m1'];
$m2 = $_POST['m2'];
$m3 = $_POST['m3'];
$m4 = $_POST['m4'];
$m5 = $_POST['m5'];

// Insert marks
$query = "INSERT INTO vtu_results(regno, math, ddco, os, dsa, java, dvp)
          VALUES('$regno', $m0, $m1, $m2, $m3, $m4, $m5)";

if(mysqli_query($con, $query)){
    echo "<script>
            alert('Marks Saved Successfully!');
            window.location='add-marks.php';
          </script>";
} else {
    echo "<script>
            alert('Error Saving Marks!');
            window.history.back();
          </script>";
}
?>
