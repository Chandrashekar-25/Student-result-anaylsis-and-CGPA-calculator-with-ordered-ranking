<?php
// Connect to database
$con = mysqli_connect("localhost", "root", "", "vtu_result", "3306");
if (!$con) {
    die("Database connection failed!");
}

// Get ranking by total marks (descending)
$q = mysqli_query($con, "
    SELECT 
      regno,
      (math + ddco + os + dsa + java + dvp) AS total
    FROM vtu_results
    ORDER BY total DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>VTU Ranking</title>
<style>
body{
    font-family: Arial, sans-serif;
    background: #eef3ff;
}
table{
    width: 60%;
    margin: 40px auto;
    border-collapse: collapse;
    font-size: 18px;
}
th, td{
    border: 1px solid #333;
    padding: 10px;
    text-align: center;
}
th{
    background: #222;
    color: #fff;
}
h2{
    text-align: center;
}
</style>
</head>

<body>

<h2>VTU Topper List & Ranking</h2>

<table>
<tr>
    <th>Rank</th>
    <th>Register Number</th>
    <th>Total Marks (out of 600)</th>
</tr>

<?php
$rank = 1;
while ($row = mysqli_fetch_assoc($q)) {
    echo "<tr>";
    echo "<td>" . $rank . "</td>";
    echo "<td>" . $row['regno'] . "</td>";
    echo "<td>" . $row['total'] . "</td>";
    echo "</tr>";
    $rank++;
}
?>

</table>

</body>
</html>
