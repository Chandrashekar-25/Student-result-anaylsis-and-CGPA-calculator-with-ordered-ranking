<?php
session_start();
// Direct connection for robustness, replace with include '../config.php'; if applicable
$con = mysqli_connect("localhost", "root", "", "srms", 3306);
if (!$con) { die("Error in connection: " . mysqli_connect_error()); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 🔒 FIX 1: Use prepared statement to fetch password hash
    $stmt = $con->prepare("SELECT password FROM admin WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // 🔒 FIX 2: Use password_verify()
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin'] = $username; // ✅ SETS THE CORRECT 'admin' KEY
            header("Location: admin-dashboard.php");
            exit;
        }
    }

    echo "<script>alert('Invalid Login'); window.location='../service-pages/admin-login.html';</script>";
    exit;
}
?>