<?php
session_start();

if(isset($_POST['regno'])){
    $regno = $_POST['regno'];

    // Connect to VTU database
    $con = mysqli_connect("localhost","root","","vtu_result","3306");
    if(!$con){ die("Database connection failed"); }

    // Fetch student record
    $q = mysqli_query($con,"SELECT * FROM vtu_results WHERE regno='$regno'");
    
    if(mysqli_num_rows($q)==0){
        echo "<script>alert('Invalid Register Number'); window.history.back();</script>";
        exit;
    }

    $data = mysqli_fetch_assoc($q);

    // Subjects
    $subjects = [
        "Mathematics" => $data['math'],
        "DDCO" => $data['ddco'],
        "Operating Systems" => $data['os'],
        "Data Structures & Applications" => $data['dsa'],
        "OOPS with Java" => $data['java'],
        "Data Visualization with Python" => $data['dvp']
    ];

    // VTU Credits
    $credits = [4,4,4,4,3,3];

    function gradePoint($m){
        if($m>=90) return 10;
        if($m>=80) return 9;
        if($m>=70) return 8;
        if($m>=60) return 7;
        if($m>=50) return 6;
        if($m>=40) return 4;
        return 0;
    }

    $sumcg = 0;
    $total = 0;
    $i = 0;
    foreach($subjects as $m){
        $gp = gradePoint($m);
        $sumcg += $gp * $credits[$i];
        $total += $m;
        $i++;
    }

    $cgpa = round($sumcg / 22, 2);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>VTU Result</title>
<style>
table{
    border-collapse: collapse;
    width: 70%;
    margin: auto;
    font-size: 18px;
}
td,th{
    padding: 10px;
    border: 1px solid #333;
}
h2{
    text-align: center;
    margin-top: 30px;
}
.pass{ color: green; font-weight:bold;}
.fail{ color: red; font-weight:bold;}
</style>
</head>
<body>

<h2>VTU STUDENT RESULT</h2>

<table>
<tr>
    <th>Subject</th>
    <th>Marks</th>
    <th>Total</th>
    <th>Status</th>
</tr>

<?php foreach($subjects as $sub=>$mark){ ?>
<tr>
    <td><?= $sub ?></td>
    <td><?= $mark ?></td>
    <td>/100</td>
    <td class="<?= ($mark>=40?'pass':'fail') ?>">
        <?= ($mark>=40?'PASS':'FAIL') ?>
    </td>
</tr>
<?php } ?>

<tr>
    <th>Subtotal</th>
    <td><?= $total ?></td>
    <td colspan="2">/600</td>
</tr>

<tr>
    <th>CGPA</th>
    <td colspan="3"><?= $cgpa ?></td>
</tr>

</table>

</body>
</html>
