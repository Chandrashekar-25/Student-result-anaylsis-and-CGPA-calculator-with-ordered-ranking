CREATE DATABASE IF NOT EXISTS vtu_result;
USE vtu_result;

DROP TABLE IF EXISTS vtu_results;

CREATE TABLE vtu_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    regno VARCHAR(50) NOT NULL,
    math INT NOT NULL,
    ddco INT NOT NULL,
    os INT NOT NULL,
    dsa INT NOT NULL,
    java INT NOT NULL,
    dvp INT NOT NULL
);
