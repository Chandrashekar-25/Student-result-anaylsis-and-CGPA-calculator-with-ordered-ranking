<?php
// Connect to database
$con = mysqli_connect("localhost", "root", "", "vtu_result", "3306");
if(!$con){
    die("Database connection failed!");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add VTU Marks</title>
<style>
body{
    font-family: Arial, sans-serif;
    background: #eef2ff;
}
.container{
    width: 40%;
    margin: 50px auto;
    background: #fff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 15px #ccc;
}
input{
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    font-size: 16px;
}
button{
    padding: 12px 20px;
    background: #007bff;
    border: none;
    color: #fff;
    font-size: 18px;
    border-radius: 5px;
    cursor: pointer;
}
button:hover{
    background: #0056b3;
}
h2{
    text-align: center;
}
</style>
</head>
<body>

<div class="container">
<h2>Add VTU Marks</h2>

<form method="POST" action="process-marks.php">

<label>Register Number (USN)</label>
<input type="text" name="regno" required>

<label>Mathematics</label>
<input type="number" name="m0" min="0" max="100" required>

<label>DDCO</label>
<input type="number" name="m1" min="0" max="100" required>

<label>Operating Systems</label>
<input type="number" name="m2" min="0" max="100" required>

<label>Data Structures & Applications</label>
<input type="number" name="m3" min="0" max="100" required>

<label>OOPS with Java</label>
<input type="number" name="m4" min="0" max="100" required>

<label>Data Visualization with Python</label>
<input type="number" name="m5" min="0" max="100" required>

<button type="submit">Save Marks</button>

</form>

</div>

</body>
</html>
