<?php
include 'config.php';
function gp($m){ if($m>=90)return 10; if($m>=80)return 9; if($m>=70)return 8; if($m>=60)return 7; if($m>=55)return 6; if($m>=50)return 5; if($m>=45)return 4; return 0;}
$res=mysqli_query($conn,"SELECT * FROM vtu_results");
$list=[];
while($r=mysqli_fetch_assoc($res)){
    $cg=round((gp($r['math'])+gp($r['ddco'])+gp($r['os'])+gp($r['dsa'])+gp($r['java'])+gp($r['dvp']))/6,2);
    $list[]=['regno'=>$r['regno'],'cgpa'=>$cg];
}
usort($list,function($a,$b){return $b['cgpa']<=>$a['cgpa'];});
?>
<html><body><h2>CGPA Ranking</h2><table border=1><tr><th>Rank</th><th>Reg No</th><th>CGPA</th></tr>
<?php $i=1; foreach($list as $s){echo "<tr><td>$i</td><td>{$s['regno']}</td><td>{$s['cgpa']}</td></tr>";$i++;} ?>
</table></body></html>
