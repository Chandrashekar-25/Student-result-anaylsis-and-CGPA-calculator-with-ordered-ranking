<?php
session_start();
?>
<html>
<head>
<link rel='stylesheet' href='../assets/css/style.css'>
<title>SRMS Login</title>
</head>
<body>
<div class='card'>
<h2>Login</h2>
<form method='post' action='../controllers/check_login.php'>
<select name='role'>
<option value='admin'>Admin</option>
<option value='student'>Student</option>
</select><br><br>
<input type='text' name='username' placeholder='Username/USN'><br><br>
<input type='password' name='password' placeholder='Password'><br><br>
<button type='submit'>Login</button>
</form>
</div>
</body>
</html>
