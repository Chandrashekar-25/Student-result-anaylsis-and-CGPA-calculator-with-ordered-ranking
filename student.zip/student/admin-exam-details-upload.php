<?php
include 'config.php';
$message = "";
function vtu_grade_point($marks){return 0;}
if (isset($_POST['upload_csv'])) {
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
        $tmp = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($tmp, "r");
        fgetcsv($handle);
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $regno = $data[0];
            $math  = $data[1];
            $ddco  = $data[2];
            $os    = $data[3];
            $dsa   = $data[4];
            $java  = $data[5];
            $dvp   = $data[6];
            $sql = "INSERT INTO vtu_results (regno, math, ddco, os, dsa, java, dvp)
                    VALUES ('$regno','$math','$ddco','$os','$dsa','$java','$dvp')
                    ON DUPLICATE KEY UPDATE 
                    math='$math', ddco='$ddco', os='$os', dsa='$dsa', java='$java', dvp='$dvp'";
            mysqli_query($conn, $sql);
        }
        $message = "CSV Uploaded Successfully!";
    } else {$message="Please select a valid CSV file.";}
}
if (isset($_POST['save_manual'])) {
    $regno=$_POST['regno'];$math=$_POST['math'];$ddco=$_POST['ddco'];$os=$_POST['os'];$dsa=$_POST['dsa'];$java=$_POST['java'];$dvp=$_POST['dvp'];
    $sql="INSERT INTO vtu_results (regno, math, ddco, os, dsa, java, dvp)
          VALUES ('$regno','$math','$ddco','$os','$dsa','$java','$dvp')
          ON DUPLICATE KEY UPDATE math='$math', ddco='$ddco', os='$os', dsa='$dsa', java='$java', dvp='$dvp'";
    mysqli_query($conn,$sql);
    $message="Marks Saved Successfully!";
}
?>
<!DOCTYPE html><html><head><title>Admin – Upload Exam Details</title></head><body>
<?php if ($message!="") echo "<script>alert('$message');</script>"; ?>
<h2>ADMIN – Upload Student Marks</h2>
<form method="POST" enctype="multipart/form-data">
<input type="file" name="csv_file" accept=".csv" required>
<button type="submit" name="upload_csv">Upload CSV</button></form><hr>
<form method="POST">
<label>Register Number:</label><input type="text" name="regno" required>
<label>Mathematics:</label><input type="number" name="math" required>
<label>DDCO:</label><input type="number" name="ddco" required>
<label>Operating Systems:</label><input type="number" name="os" required>
<label>DSA:</label><input type="number" name="dsa" required>
<label>OOPS with Java:</label><input type="number" name="java" required>
<label>DVP:</label><input type="number" name="dvp" required>
<button type="submit" name="save_manual">Save Marks</button></form></body></html>
