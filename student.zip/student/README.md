# Student-Result-Management-System

## Description:- 

A simple web application through which a student can easily get their result and a teacher(Admin) can easily upload the student's mark details through a form.

## Working Functionality:-

First, as a student you have to enter the email address and registration number to get your results and if you are a teacher(Admin) then login with appropriate credentials i.e official admin email address(admin@gmail.com) and password(1234) and fill up the individual student's mark details and it will automatically stored into the database.

## Technology Stack:-

*  HTML 5
*  CSS 3
*  Bootstrap
*  Javascript
*  PHP 7
*  MySQL Database
*  Some Coffee ☕ (Most Important for Programmers)






