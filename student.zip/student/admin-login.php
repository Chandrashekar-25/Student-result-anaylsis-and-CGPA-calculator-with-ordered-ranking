<?php
session_start();

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // DEFAULT ADMIN CREDENTIALS
    if ($username == "admin" && $password == "admin123") {

        $_SESSION['admin'] = true;
        header("Location: admin-dashboard.php");
        exit;

    } else {
        $msg = "Invalid Login! Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>

    <style>
        body { 
            background:#eef2ff; 
            font-family:Arial; 
        }
        .box {
            width:350px; 
            margin:100px auto; 
            background:white; 
            padding:25px; 
            border-radius:10px;
            box-shadow:0 0 10px #aaa;
        }
        input, button {
            width:100%; 
            padding:10px;
            margin:8px 0;
        }
        button {
            background:#4f46e5; 
            color:white; 
            border:none;
            cursor:pointer;
        }
        button:hover { opacity:0.8; }
        .error { color:red; }
    </style>

</head>
<body>

<div class="box">
    <h2>Admin Login</h2>

    <?php if ($msg != "") echo "<p class='error'>$msg</p>"; ?>

    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>

</div>

</body>
</html>
