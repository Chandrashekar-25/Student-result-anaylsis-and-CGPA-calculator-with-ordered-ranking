<?php
include 'config.php';
$res=mysqli_query($conn,"SELECT regno,(math+ddco+os+dsa+java+dvp) total FROM vtu_results ORDER BY total DESC");
?>
<html><body><h2>Total Ranking</h2><table border=1><tr><th>Rank</th><th>Reg No</th><th>Total</th></tr>
<?php $r=1; while($row=mysqli_fetch_assoc($res)){echo "<tr><td>$r</td><td>{$row['regno']}</td><td>{$row['total']}</td></tr>";$r++;} ?>
</table></body></html>
