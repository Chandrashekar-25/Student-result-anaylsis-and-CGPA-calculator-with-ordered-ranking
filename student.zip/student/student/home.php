<?php
session_start();
include '../config.php'; // Assuming this defines $conn

if(!isset($_SESSION['student'])){
    header('Location: ../auth/login.php');
    exit;
}

$u = $_SESSION['student'];

// 1. 🔒 FIX: Secure student details lookup using Prepared Statement
$q = $conn->prepare("SELECT id, name FROM students WHERE usn=?");
$q->bind_param("s", $u);
$q->execute();
$q->bind_result($id, $name);
$q->fetch();
$q->close();

if (!isset($id)) {
    echo "Student profile not found. Please contact admin.";
    session_destroy();
    exit;
}

// 2. 🔒 FIX: Secure result lookup using Prepared Statement
$r = $conn->prepare("SELECT * FROM results WHERE student_id=?");
$r->bind_param("i", $id);
$r->execute();
$result = $r->get_result();
$row = $result->fetch_assoc();
$r->close();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
</head>
<body>
    <h2>Welcome <?php echo htmlspecialchars($name); ?></h2>
    <a href='../auth/logout.php'>Logout</a>
    <br><br>

    <?php if($row): ?>
        <h3>Your Result</h3>
        <table>
            <tr><th>Subject</th><th>Marks</th></tr>
            <tr><td>Mathematics</td><td><?php echo htmlspecialchars($row['mathematics']); ?></td></tr>
            <tr><td>DDCO</td><td><?php echo htmlspecialchars($row['ddco']); ?></td></tr>
            <tr><td>OS</td><td><?php echo htmlspecialchars($row['os']); ?></td></tr>
            <tr><td>DSA</td><td><?php echo htmlspecialchars($row['dsa']); ?></td></tr>
            <tr><td>JAVA</td><td><?php echo htmlspecialchars($row['java']); ?></td></tr>
            <tr><td>DVP</td><td><?php echo htmlspecialchars($row['dvp']); ?></td></tr>
        </table>
        <br>
        <strong>Total Marks:</strong> <?php echo htmlspecialchars($row['total']); ?><br>
        <strong>CGPA:</strong> <?php echo htmlspecialchars($row['cgpa']); ?><br>
    <?php else: ?>
        <p>No results found for your USN.</p>
    <?php endif; ?>
</body>
</html>