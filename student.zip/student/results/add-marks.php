<?php $con=mysqli_connect("localhost","root","","vtu_result","3306"); ?>
<html><body>
<h2>Add VTU Marks</h2>

<form method="post" action="process-marks.php">
RegNo: <input name="regno"><br><br>
Math: <input name="m0"><br>
DDCO: <input name="m1"><br>
OS: <input name="m2"><br>
DSA: <input name="m3"><br>
JAVA: <input name="m4"><br>
DVP: <input name="m5"><br>
<br>
<button>Save Marks</button>
</form>

</body></html>
