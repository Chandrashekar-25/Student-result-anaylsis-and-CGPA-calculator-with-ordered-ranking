<?php
$con=mysqli_connect("localhost","root","","vtu_result","3306");

$q=mysqli_query($con,"
SELECT regno, (math+ddco+os+dsa+java+dvp) AS total
FROM vtu_results ORDER BY total DESC
");
?>
<html><body>
<h2 align="center">VTU TOPPER LIST</h2>

<table border="1" cellpadding="10" align="center">
<tr><th>Rank</th><th>RegNo</th><th>Total</th></tr>

<?php
$rk=1;
while($r=mysqli_fetch_assoc($q)){
 echo "<tr><td>$rk</td><td>{$r['regno']}</td><td>{$r['total']}</td></tr>";
 $rk++;
}
?>
</table>

</body></html>
