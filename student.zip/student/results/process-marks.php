<?php
$con=mysqli_connect("localhost","root","","vtu_result","3306");

$r=$_POST['regno'];

mysqli_query($con,"
INSERT INTO vtu_results(regno,math,ddco,os,dsa,java,dvp)
VALUES(
 '$r',
 {$_POST['m0']},
 {$_POST['m1']},
 {$_POST['m2']},
 {$_POST['m3']},
 {$_POST['m4']},
 {$_POST['m5']}
)");

echo "<script>alert('Marks Saved');window.location='add-marks.php';</script>";
?>
