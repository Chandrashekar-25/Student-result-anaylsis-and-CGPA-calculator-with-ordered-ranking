CREATE DATABASE IF NOT EXISTS vtu_result;
USE vtu_result;

DROP TABLE IF EXISTS vtu_results;

CREATE TABLE vtu_results(
 id INT AUTO_INCREMENT PRIMARY KEY,
 regno VARCHAR(50),
 math INT,
 ddco INT,
 os INT,
 dsa INT,
 java INT,
 dvp INT
);
