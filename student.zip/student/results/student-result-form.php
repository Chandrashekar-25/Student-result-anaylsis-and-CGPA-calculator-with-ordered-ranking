<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $regno = $_POST['regno'];

    $con = mysqli_connect("localhost", "root", "", "vtu_result", "3306");
    if (!$con) { die("Database Connection Failed"); }

    $q = mysqli_query($con, "SELECT * FROM vtu_results WHERE regno='$regno'");
    if (mysqli_num_rows($q) == 0) {
        echo "<script>alert('Invalid Register Number');history.back();</script>";
        exit;
    }

    $data = mysqli_fetch_assoc($q);

    $subjects = [
        "Mathematics" => $data['math'],
        "DDCO" => $data['ddco'],
        "Operating Systems" => $data['os'],
        "Data Structures & Applications" => $data['dsa'],
        "OOPS with Java" => $data['java'],
        "Data Visualization with Python" => $data['dvp']
    ];

    $credits = [4,4,4,4,3,3];

    function gp($m){
        if($m>=90) return 10;
        if($m>=80) return 9;
        if($m>=70) return 8;
        if($m>=60) return 7;
        if($m>=50) return 6;
        if($m>=40) return 4;
        return 0;
    }

    $sumcg=0; $total=0; $i=0;

    foreach ($subjects as $m) {
        $sumcg += gp($m) * $credits[$i];
        $total += $m;
        $i++;
    }

    $cgpa = round($sumcg / 22, 2);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>VTU RESULT</title>
</head>
<body>

<?php if(!isset($data)) { ?>

<!-- 🔵 THIS IS THE FORM — SHOWN ONLY ONCE -->
<h2 align="center">Fill the Result Details</h2>

<form method="POST" align="center">
    <label><b>Register Number:</b></label>
    <input type="text" name="regno" required>
    <br><br>
    <input type="submit" value="Get Result">
</form>

<?php } else { ?>

<!-- 🔵 RESULT DISPLAY — SHOWS AFTER SUBMIT -->
<h2 align="center">VTU RESULT</h2>

<table border="1" cellpadding="10" align="center">
<tr><th>Subject</th><th>Marks</th><th>Total</th><th>Status</th></tr>

<?php foreach ($subjects as $s => $m) { ?>
<tr>
    <td><?= $s ?></td>
    <td><?= $m ?></td>
    <td>/100</td>
    <td><?= ($m >= 40 ? 'PASS' : 'FAIL') ?></td>
</tr>
<?php } ?>

<tr><th>Subtotal</th><td><?= $total ?></td><td colspan="2">/600</td></tr>
<tr><th>CGPA</th><td colspan="3"><?= $cgpa ?></td></tr>
</table>

<?php } ?>

</body>
</html>
