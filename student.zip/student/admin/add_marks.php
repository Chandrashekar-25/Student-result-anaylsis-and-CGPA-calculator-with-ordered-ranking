<?php
session_start();
include '../config.php'; // Assuming this defines $conn

if (!isset($_SESSION['admin'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Function to calculate Grade Point (GP)
function gp($m) {
    if($m >= 90) return 10;
    if($m >= 80) return 9;
    if($m >= 70) return 8;
    if($m >= 60) return 7;
    if($m >= 50) return 6;
    if($m >= 40) return 4;
    return 0;
}

if (isset($_POST['submit'])) {
    // 1. Sanitize and Validate USN and Marks
    $u = filter_input(INPUT_POST, 'usn', FILTER_SANITIZE_STRING);
    $marks = [];
    $all_valid = true;
    for ($i = 0; $i < 6; $i++) {
        $m = filter_input(INPUT_POST, "m$i", FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 100]]);
        if ($m === false || $m === null) {
            echo "<script>alert('Error: Mark for subject " . ($i+1) . " is invalid.');</script>";
            $all_valid = false;
            break;
        }
        $marks[] = $m;
    }

    if (!$all_valid) { exit; }

    // 2. 🔒 FIX: Securely get student ID
    $q = $conn->prepare("SELECT id FROM students WHERE usn=?");
    $q->bind_param("s", $u);
    $q->execute();
    $r = $q->get_result()->fetch_assoc();
    $q->close();

    if (!$r) {
        echo "<script>alert('Student USN not found.');</script>";
        exit;
    }
    $sid = $r['id'];

    // 3. Calculation Logic
    $subs = [4, 4, 4, 4, 3, 3]; // Credits
    $sumcg = 0; $sumcr = array_sum($subs);
    $total = array_sum($marks);

    for ($i = 0; $i < 6; $i++) {
        $sumcg += gp($marks[$i]) * $subs[$i];
    }
    $cg = round($sumcg / $sumcr, 2);

    // 4. 🔒 FIX: Securely insert/update results (Requires UNIQUE KEY on student_id in results table)
    $query = "INSERT INTO results(student_id, mathematics, ddco, os, dsa, java, dvp, total, cgpa)
              VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
              ON DUPLICATE KEY UPDATE
              mathematics=VALUES(mathematics), ddco=VALUES(ddco), os=VALUES(os), dsa=VALUES(dsa), java=VALUES(java), dvp=VALUES(dvp), total=VALUES(total), cgpa=VALUES(cgpa)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiiiiiidi", $sid, $marks[0], $marks[1], $marks[2], $marks[3], $marks[4], $marks[5], $total, $cg);

    if ($stmt->execute()) {
        echo "<script>alert('Marks Saved/Updated Successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}
?>

<h2>Add Marks</h2>
<form method='post'>
    USN: <input name='usn' required><br><br>
    Math: <input name='m0' type='number' min='0' max='100' required><br>
    DDCO: <input name='m1' type='number' min='0' max='100' required><br>
    OS: <input name='m2' type='number' min='0' max='100' required><br>
    DSA: <input name='m3' type='number' min='0' max='100' required><br>
    JAVA: <input name='m4' type='number' min='0' max='100' required><br>
    DVP: <input name='m5' type='number' min='0' max='100' required><br>
    <button name='submit'>Save Marks</button>
</form>