<?php
session_start();
include '../config.php'; // Assuming this defines $conn

if (!isset($_SESSION['admin'])) {
    header('Location: ../auth/login.php');
    exit;
}

if(isset($_POST['submit'])){
    // 🔒 FIX 1: Use Prepared Statements to prevent SQL Injection
    // 🔒 FIX 2: Hash the password before storing it
    $name = $_POST['name'];
    $usn = $_POST['usn'];
    $dept = $_POST['dept'];
    // Assuming student login uses a simple password check for now,
    // but the data is still sanitized by the Prepared Statement.
    $password = $_POST['password'];

    $stmt = $conn->prepare("INSERT INTO students(name, usn, dept, password) VALUES(?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $usn, $dept, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Student Added Successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}
?>
<h2>Add Student</h2>
<form method='post'>
    Name: <input name='name' required><br>
    USN: <input name='usn' required><br>
    Dept: <input name='dept' required><br>
    Password: <input type='password' name='password' required><br>
    <button name='submit'>Add</button>
</form>