<?php session_start(); if(!isset($_SESSION['admin'])){header('Location: ../auth/login.php');}
echo "<h2>Admin Dashboard</h2><a href='add_student.php'>Add Student</a><br><a href='add_marks.php'>Add Marks</a><br><a href='view_results.php'>View Results</a>";
?>
