<?php
include '../config.php'; // Assuming this defines $conn
?>
<h2>All Results</h2>
<table border=1>
<tr><th>Name</th><th>USN</th><th>Total</th><th>CGPA</th></tr>
<?php
// Query is safe as it contains no user input
$q=mysqli_query($conn,"SELECT s.name,s.usn,r.total,r.cgpa FROM results r JOIN students s ON r.student_id=s.id");
while($row=mysqli_fetch_assoc($q)){
    // 🔒 FIX: Use htmlspecialchars() for XSS prevention
    echo "<tr><td>" . htmlspecialchars($row['name']) . "</td><td>" . htmlspecialchars($row['usn']) . "</td><td>" . htmlspecialchars($row['total']) . "</td><td>" . htmlspecialchars($row['cgpa']) . "</td></tr>";
}
?>
</table>