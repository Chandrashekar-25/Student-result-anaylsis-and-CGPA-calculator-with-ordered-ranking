<?php
session_start();

// ✅ FIX SESSION KEY: Check for the consistent 'admin' key
if (!isset($_SESSION['admin'])) { 
    header("Location: admin-login.html");
    exit;
}

// ✅ Use the consistent 'admin' key
$admin = $_SESSION['admin']; 
?>