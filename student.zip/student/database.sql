CREATE DATABASE IF NOT EXISTS giet_exam;
USE giet_exam;

CREATE TABLE admin_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    emailid VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

INSERT INTO admin_info (username, emailid, password)
VALUES ('admin', 'admin@gmail.com', 'admin123');

CREATE TABLE studentresult (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admisnno VARCHAR(50),
    studentname VARCHAR(255),
    department VARCHAR(255),
    subject VARCHAR(255),
    semester VARCHAR(20),
    year VARCHAR(20),
    internal INT,
    external INT,
    total INT
);
