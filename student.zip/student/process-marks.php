<?php
// Database connection
include 'config.php';

// Ensure POST is received
if (!isset($_POST['submit'])) {
    echo "<script>alert('Invalid Access!'); window.location='add-marks.php';</script>";
    exit;
}

// Collect POST data safely
$regno = $_POST['regno'];
$math  = $_POST['math'];
$ddco  = $_POST['ddco'];
$os    = $_POST['os'];
$dsa   = $_POST['dsa'];
$java  = $_POST['java'];
$dvp   = $_POST['dvp'];

// Validate empty fields
if ($regno == "" || 
    $math == "" || $ddco == "" || $os == "" ||
    $dsa == "" || $java == "" || $dvp == "") {

    echo "<script>
            alert('All fields are required!');
            window.history.back();
          </script>";
    exit;
}

// Insert or Update Query
$query = "
INSERT INTO vtu_results (regno, math, ddco, os, dsa, java, dvp)
VALUES ('$regno', '$math', '$ddco', '$os', '$dsa', '$java', '$dvp')
ON DUPLICATE KEY UPDATE 
    math='$math',
    ddco='$ddco',
    os='$os',
    dsa='$dsa',
    java='$java',
    dvp='$dvp'
";

// Execute Query
if(mysqli_query($conn, $query)){
    echo "<script>
            alert('Marks Saved Successfully!');
            window.location='add-marks.php';
          </script>";
} else {
    echo "<script>
            alert('Error Saving Marks: " . mysqli_error($conn) . "');
            window.history.back();
          </script>";
}
?>
